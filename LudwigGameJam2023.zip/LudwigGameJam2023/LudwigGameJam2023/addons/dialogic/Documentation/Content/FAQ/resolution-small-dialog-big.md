# Text box to big?

**My resolution is too small and my dialog box is too big. Help!**
The scale of dialogue boxes and text are set in the Theme selected for the project. If your resolution is too small, the default one may be too big. Create a new theme and make the box and text sizes smaller until it fits appropriately.